/**
 * Written by Robert Eriksson
 * This just prints the multiplication table
 * for the number 8
 */

const number = 8;

for (let i = 0; i <= 10; i++) {
    console.log(number + " * " + i + " = " + number * i)
}