/**
 * Written by Robert Eriksson
 * It's just an exercise to test datatypes
 * and write them to console  
 **/

let health = 100;
let damage = 63.875;
let damageTaken = true;
let healthWarning = "Your health is below 50%";

console.log(health + ", " + damage + ", " + damageTaken + ", " + healthWarning);