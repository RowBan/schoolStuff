/**
 * Written by Robert Eriksson
 * It simply prints first name, surname and email.
 **/

let firstName = "Ree";
let surName = "Putitinputin";
let email = "nitup.rimidalv@something.ru";

console.log(firstName + " " + surName + ", " + email);