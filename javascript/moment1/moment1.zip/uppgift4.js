/**
 * Written by Robert Eriksson
 * this prints every number that is uneven
 * between the numbers 3 and 23.
 */

for (i = 3; i <= 23; i++) {
    if (i % 2 !== 0) {
        console.log(i);
    }
}